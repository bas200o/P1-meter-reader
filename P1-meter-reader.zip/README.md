# P1-meter-reader
An application to read the dutch P1 smart reader
