var Module = module.exports;
Module.doAthing = postEvent;

function postEvent () {
    console.log("I did a thing");
};


